//Autorin: Paiata Ustinovich,
//Version: IntelliJ IDEA 2021.1.2 (Community Edition)
//Build #IC-211.7442.40, built on June 1, 2021
//Runtime version: 11.0.11+9-b1341.57 amd64
//VM: Dynamic Code Evolution 64-Bit Server VM by JetBrains s.r.o.

package mobileOperator;

//Main Klasse, die Klasse Aplication mit Benutzer-Menü aufruft
public class Runner {
    public static void main(String[] args) {
    Application application = new Application();
    application.mainMenu();
    }
}
